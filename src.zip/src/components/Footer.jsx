import React from 'react';

const Footer = () => {
    return (
        <footer className="py-4">
            <div className="container mx-auto">footer text</div>
        </footer>
    );
};

export default Footer;
