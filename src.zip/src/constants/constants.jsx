const API_KEY = import.meta.env.VITE_API_KEY;
const STORAGE_KEY = 'hesflix';
const BASE_URL = 'https://api.themoviedb.org/3';

export { API_KEY, STORAGE_KEY, BASE_URL };
