import React from 'react';

const Contacts = () => {
    return <div>Contacts</div>;
};

export default Contacts;
